# Spider mites > 2025-03-24 10:52am
https://universe.roboflow.com/spidermites/spider-mites-y6lao

Provided by a Roboflow user
License: CC BY 4.0

