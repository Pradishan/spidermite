# Spider mites > 2025-03-22 1:38pm
https://universe.roboflow.com/spidermites/spider-mites-y6lao

Provided by a Roboflow user
License: CC BY 4.0

